if grep -Fqvf pass.txt passwordlist.txt; then
    echo $"There are lines in file1 that don’t occur in file2."
fi
